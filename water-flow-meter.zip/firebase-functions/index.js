const functions = require("firebase-functions")
const admin = require("firebase-admin")
const nodemailer = require("nodemailer")

admin.initializeApp()

// Configuração do transporte de email
const mailTransport = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "seu-email@gmail.com",
    pass: "sua-senha-de-app",
  },
})

// Função para enviar emails de alerta
exports.sendEmailAlerts = functions.database.ref("/alerts/{alertId}").onCreate(async (snapshot, context) => {
  const alertData = snapshot.val()

  // Verifica se o alerta já foi processado
  if (alertData.processed) {
    return null
  }

  // Marca o alerta como processado para evitar duplicação
  await admin.database().ref(`/alerts/${context.params.alertId}`).update({
    processed: true,
  })

  // Verifica se há destinatários
  if (!alertData.recipients || !alertData.recipients.length) {
    console.log("Nenhum destinatário configurado para este alerta")
    return null
  }

  // Prepara o email
  const mailOptions = {
    from: '"Sistema de Monitoramento de Água" <seu-email@gmail.com>',
    to: alertData.recipients.join(", "),
    subject: alertData.subject,
    text: alertData.message,
    html: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
               <h2 style="color: #0066cc;">${alertData.subject}</h2>
               <p>${alertData.message.replace(/\n/g, "<br>")}</p>
               <p style="color: #666; font-size: 0.9em;">Enviado em: ${alertData.timestamp}</p>
               <hr>
               <p style="color: #666; font-size: 0.8em;">
                 Esta é uma mensagem automática do seu Sistema de Monitoramento de Água.
                 Não responda a este email.
               </p>
             </div>`,
  }

  try {
    // Envia o email
    await mailTransport.sendMail(mailOptions)
    console.log("Email enviado com sucesso para:", alertData.recipients.join(", "))

    // Registra o envio bem-sucedido
    await admin.database().ref(`/alerts/${context.params.alertId}`).update({
      emailSent: true,
      sentTimestamp: admin.database.ServerValue.TIMESTAMP,
    })

    return null
  } catch (error) {
    console.error("Erro ao enviar email:", error)

    // Registra a falha
    await admin.database().ref(`/alerts/${context.params.alertId}`).update({
      emailSent: false,
      error: error.message,
    })

    return null
  }
})

// Função para limpar alertas antigos (manter apenas os últimos 100)
exports.cleanupOldAlerts = functions.pubsub.schedule("every 24 hours").onRun(async (context) => {
  const alertsRef = admin.database().ref("/alerts")

  try {
    // Obtém todos os alertas ordenados por timestamp
    const snapshot = await alertsRef.orderByChild("timestamp").once("value")
    const alerts = []

    snapshot.forEach((childSnapshot) => {
      alerts.push({
        key: childSnapshot.key,
        timestamp: childSnapshot.val().timestamp,
      })
    })

    // Se houver mais de 100 alertas, remove os mais antigos
    if (alerts.length > 100) {
      const alertsToDelete = alerts.slice(0, alerts.length - 100)

      const deletePromises = alertsToDelete.map((alert) => {
        return alertsRef.child(alert.key).remove()
      })

      await Promise.all(deletePromises)
      console.log(`Removidos ${alertsToDelete.length} alertas antigos`)
    }

    return null
  } catch (error) {
    console.error("Erro ao limpar alertas antigos:", error)
    return null
  }
})

// Função para gerar relatório diário de consumo
exports.generateDailyReport = functions.pubsub.schedule("0 0 * * *").onRun(async (context) => {
  try {
    // Obtém os dados do sistema
    const systemSnapshot = await admin.database().ref("/waterSystem").once("value")
    const systemData = systemSnapshot.val()

    if (!systemData) {
      console.log("Nenhum dado do sistema encontrado")
      return null
    }

    // Obtém configurações de email
    const emailConfigSnapshot = await admin.database().ref("/emailConfig").once("value")
    const emailConfig = emailConfigSnapshot.val()

    if (!emailConfig || !emailConfig.enabled) {
      console.log("Configuração de email não encontrada ou desativada")
      return null
    }

    // Prepara os destinatários
    const recipients = []
    if (emailConfig.recipients) {
      Object.values(emailConfig.recipients).forEach((recipient) => {
        if (recipient.enabled) {
          recipients.push(recipient.email)
        }
      })
    }

    if (recipients.length === 0) {
      console.log("Nenhum destinatário configurado para relatórios diários")
      return null
    }

    // Formata a data
    const today = new Date()
    const dateStr = today.toLocaleDateString("pt-BR")

    // Prepara o conteúdo do relatório
    let tankInfo = ""
    if (systemData.tanks) {
      Object.entries(systemData.tanks).forEach(([key, tank]) => {
        if (tank.enabled) {
          tankInfo += `<tr>
                         <td>Caixa ${Number.parseInt(key) + 1}</td>
                         <td>${tank.level.toFixed(1)}%</td>
                         <td>${((tank.level / 100) * tank.capacity).toFixed(0)} L</td>
                         <td>${tank.capacity} L</td>
                       </tr>`
        }
      })
    }

    // Prepara o email
    const mailOptions = {
      from: '"Sistema de Monitoramento de Água" <seu-email@gmail.com>',
      to: recipients.join(", "),
      subject: `Relatório Diário de Consumo de Água - ${dateStr}`,
      html: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
               <h2 style="color: #0066cc;">Relatório Diário de Consumo de Água</h2>
               <p>Data: <strong>${dateStr}</strong></p>
               
               <h3>Resumo do Consumo</h3>
               <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                 <tr style="background-color: #f2f2f2;">
                   <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Métrica</th>
                   <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Valor</th>
                 </tr>
                 <tr>
                   <td style="padding: 8px; border: 1px solid #ddd;">Consumo Diário</td>
                   <td style="padding: 8px; border: 1px solid #ddd;">${systemData.dailyUsage.toFixed(2)} L</td>
                 </tr>
                 <tr>
                   <td style="padding: 8px; border: 1px solid #ddd;">Vazão Atual</td>
                   <td style="padding: 8px; border: 1px solid #ddd;">${systemData.flowRate.toFixed(2)} L/min</td>
                 </tr>
                 <tr>
                   <td style="padding: 8px; border: 1px solid #ddd;">Volume Total</td>
                   <td style="padding: 8px; border: 1px solid #ddd;">${systemData.totalVolume.toFixed(2)} L</td>
                 </tr>
                 <tr>
                   <td style="padding: 8px; border: 1px solid #ddd;">Vazamento Detectado</td>
                   <td style="padding: 8px; border: 1px solid #ddd;">${systemData.leakDetected ? "Sim" : "Não"}</td>
                 </tr>
               </table>
               
               <h3>Status das Caixas d'Água</h3>
               <table style="width: 100%; border-collapse: collapse;">
                 <tr style="background-color: #f2f2f2;">
                   <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Caixa</th>
                   <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Nível</th>
                   <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Volume</th>
                   <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Capacidade</th>
                 </tr>
                 ${tankInfo}
               </table>
               
               <p style="margin-top: 20px;">Última atualização: ${systemData.lastUpdate}</p>
               
               <hr>
               <p style="color: #666; font-size: 0.8em;">
                 Esta é uma mensagem automática do seu Sistema de Monitoramento de Água.
                 Não responda a este email.
               </p>
             </div>`,
    }

    // Envia o email
    await mailTransport.sendMail(mailOptions)
    console.log("Relatório diário enviado com sucesso para:", recipients.join(", "))

    // Registra o envio do relatório
    await admin
      .database()
      .ref("/reports")
      .push({
        type: "daily",
        timestamp: admin.database.ServerValue.TIMESTAMP,
        recipients: recipients,
        data: {
          dailyUsage: systemData.dailyUsage,
          flowRate: systemData.flowRate,
          totalVolume: systemData.totalVolume,
          leakDetected: systemData.leakDetected,
        },
      })

    return null
  } catch (error) {
    console.error("Erro ao gerar relatório diário:", error)
    return null
  }
})

