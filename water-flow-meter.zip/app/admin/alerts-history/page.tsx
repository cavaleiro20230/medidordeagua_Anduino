"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"
import {
  Search,
  Filter,
  Eye,
  Download,
  AlertTriangle,
  MailCheck,
  Droplet,
  Calendar,
  Clock,
  RefreshCw,
} from "lucide-react"

// Tipos de dados
interface Alert {
  id: string
  subject: string
  message: string
  type: "low_level" | "leak" | "high_usage"
  timestamp: string
  recipients: string[]
  emailSent: boolean
  sentTimestamp?: string
}

// Dados de exemplo
const mockAlerts: Alert[] = [
  {
    id: "1",
    subject: "Alerta: Nível Crítico na Caixa d'Água",
    message: "Níveis críticos nas seguintes caixas:\n- Caixa 1: 18.5% (185 de 1000 litros)",
    type: "low_level",
    timestamp: "2024-03-06 14:30:22",
    recipients: ["usuario1@exemplo.com", "usuario2@exemplo.com"],
    emailSent: true,
    sentTimestamp: "2024-03-06 14:30:25",
  },
  {
    id: "2",
    subject: "Alerta: Vazamento Detectado",
    message:
      "Possível vazamento detectado!\nFluxo contínuo de água por mais de 6 horas.\nVazão atual: 1.25 L/min\nPor favor, verifique suas instalações.",
    type: "leak",
    timestamp: "2024-03-07 14:30:22",
    recipients: ["usuario1@exemplo.com"],
    emailSent: true,
    sentTimestamp: "2024-03-07 14:30:25",
  },
  {
    id: "3",
    subject: "Alerta: Consumo Elevado de Água",
    message:
      "Consumo diário acima do limite!\nConsumo atual: 250.75 litros\nLimite configurado: 200 litros\nVerifique possíveis desperdícios.",
    type: "high_usage",
    timestamp: "2024-03-08 09:15:10",
    recipients: ["usuario1@exemplo.com", "usuario2@exemplo.com"],
    emailSent: true,
    sentTimestamp: "2024-03-08 09:15:12",
  },
  {
    id: "4",
    subject: "Alerta: Nível Crítico na Caixa d'Água",
    message: "Níveis críticos nas seguintes caixas:\n- Caixa 1: 15.2% (152 de 1000 litros)",
    type: "low_level",
    timestamp: "2024-03-09 18:45:30",
    recipients: ["usuario1@exemplo.com", "usuario2@exemplo.com"],
    emailSent: false,
  },
  {
    id: "5",
    subject: "Relatório Diário de Consumo de Água",
    message: "Relatório diário gerado automaticamente.",
    type: "high_usage",
    timestamp: "2024-03-10 07:00:00",
    recipients: ["usuario1@exemplo.com", "usuario2@exemplo.com"],
    emailSent: true,
    sentTimestamp: "2024-03-10 07:00:05",
  },
]

export default function AlertsHistoryPage() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [filteredAlerts, setFilteredAlerts] = useState<Alert[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)

  // Carregar alertas
  useEffect(() => {
    // Em um ambiente real, isso seria uma chamada API
    setAlerts(mockAlerts)
    setFilteredAlerts(mockAlerts)
  }, [])

  // Filtrar alertas
  useEffect(() => {
    let result = alerts

    // Filtrar por termo de busca
    if (searchTerm) {
      result = result.filter(
        (alert) =>
          alert.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
          alert.message.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filtrar por tipo
    if (typeFilter !== "all") {
      result = result.filter((alert) => alert.type === typeFilter)
    }

    setFilteredAlerts(result)
  }, [searchTerm, typeFilter, alerts])

  // Reenviar alerta
  const resendAlert = (alertId: string) => {
    // Em um ambiente real, isso seria uma chamada API
    setAlerts(
      alerts.map((alert) => {
        if (alert.id === alertId) {
          return {
            ...alert,
            emailSent: true,
            sentTimestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
          }
        }
        return alert
      }),
    )

    toast({
      title: "Alerta reenviado",
      description: "O alerta foi reenviado com sucesso.",
    })
  }

  // Exportar alertas
  const exportAlerts = () => {
    toast({
      title: "Exportação iniciada",
      description: "Os alertas estão sendo exportados para CSV.",
    })
  }

  // Renderizar ícone de tipo de alerta
  const renderAlertTypeIcon = (type: string) => {
    switch (type) {
      case "low_level":
        return <Droplet className="h-4 w-4 text-blue-500" />
      case "leak":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "high_usage":
        return <Calendar className="h-4 w-4 text-yellow-500" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Histórico de Alertas</h1>
        <Button onClick={exportAlerts}>
          <Download className="h-4 w-4 mr-2" />
          Exportar
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <TabsList>
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="low_level">Nível Baixo</TabsTrigger>
            <TabsTrigger value="leak">Vazamentos</TabsTrigger>
            <TabsTrigger value="high_usage">Consumo Alto</TabsTrigger>
          </TabsList>
          <div className="flex gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar alertas..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Assunto</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Destinatários</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <TableRow key={alert.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {renderAlertTypeIcon(alert.type)}
                            <span>
                              {alert.type === "low_level" && "Nível Baixo"}
                              {alert.type === "leak" && "Vazamento"}
                              {alert.type === "high_usage" && "Consumo Alto"}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{alert.subject}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            {alert.timestamp}
                          </div>
                        </TableCell>
                        <TableCell>{alert.recipients.length}</TableCell>
                        <TableCell>
                          {alert.emailSent ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              <MailCheck className="h-3 w-3 mr-1" />
                              Enviado
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                              Pendente
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Dialog
                              open={isViewDialogOpen && selectedAlert?.id === alert.id}
                              onOpenChange={(open) => {
                                setIsViewDialogOpen(open)
                                if (!open) setSelectedAlert(null)
                              }}
                            >
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedAlert(alert)
                                    setIsViewDialogOpen(true)
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-md">
                                <DialogHeader>
                                  <DialogTitle>{alert.subject}</DialogTitle>
                                  <DialogDescription>Enviado em {alert.timestamp}</DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                  <div className="space-y-2">
                                    <h4 className="font-medium">Mensagem:</h4>
                                    <p className="whitespace-pre-line text-sm">{alert.message}</p>
                                  </div>
                                  <div className="space-y-2">
                                    <h4 className="font-medium">Destinatários:</h4>
                                    <ul className="list-disc list-inside text-sm">
                                      {alert.recipients.map((recipient, index) => (
                                        <li key={index}>{recipient}</li>
                                      ))}
                                    </ul>
                                  </div>
                                  <div className="space-y-2">
                                    <h4 className="font-medium">Status:</h4>
                                    <p className="text-sm">
                                      {alert.emailSent ? `Enviado em ${alert.sentTimestamp}` : "Pendente de envio"}
                                    </p>
                                  </div>
                                </div>
                                <DialogFooter>
                                  {!alert.emailSent && <Button onClick={() => resendAlert(alert.id)}>Reenviar</Button>}
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>

                            {!alert.emailSent && (
                              <Button variant="outline" size="sm" onClick={() => resendAlert(alert.id)}>
                                <RefreshCw className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4">
                        Nenhum alerta encontrado
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="low_level">
          {/* Conteúdo similar ao "all", mas filtrado para alertas de nível baixo */}
        </TabsContent>

        <TabsContent value="leak">
          {/* Conteúdo similar ao "all", mas filtrado para alertas de vazamento */}
        </TabsContent>

        <TabsContent value="high_usage">
          {/* Conteúdo similar ao "all", mas filtrado para alertas de consumo alto */}
        </TabsContent>
      </Tabs>
    </div>
  )
}

