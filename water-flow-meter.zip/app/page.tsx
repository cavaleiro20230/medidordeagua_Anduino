"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import {
  DropletIcon,
  History,
  AlertTriangle,
  Target,
  BarChart3,
  Calendar,
  AlertCircle,
  Droplets,
  ContainerIcon as Tank,
  Bell,
  BellOff,
  Save,
  RefreshCw,
  Trash2,
  LineChart,
  BarChart,
  Download,
} from "lucide-react"

export default function WaterMeterSystem() {
  // Estados para simulação de dados
  const [currentFlow, setCurrentFlow] = useState(2.5)
  const [totalVolume, setTotalVolume] = useState(1250.45)
  const [dailyUsage, setDailyUsage] = useState(125.5)
  const [monthlyUsage, setMonthlyUsage] = useState(3750.8)
  const [monthlyTarget, setMonthlyTarget] = useState(4000)
  const [leakDetected, setLeakDetected] = useState(false)
  const [costPerLiter, setCostPerLiter] = useState(0.003) // R$ 3,00 por m³

  // Estados para caixa d'água
  const [tankLevel, setTankLevel] = useState(65) // Porcentagem
  const [tankCapacity, setTankCapacity] = useState(1000) // Litros
  const [tankAlertLow, setTankAlertLow] = useState(20) // Alerta de nível baixo (%)
  const [tankAlertMid, setTankAlertMid] = useState(50) // Alerta de nível médio (%)
  const [tankAlertHigh, setTankAlertHigh] = useState(90) // Alerta de nível alto (%)
  const [tankAlertsEnabled, setTankAlertsEnabled] = useState(true)

  // Configurações de caixas d'água padrão
  const standardTanks = [
    { name: "Caixa 500L", capacity: 500 },
    { name: "Caixa 1.000L", capacity: 1000 },
    { name: "Caixa 1.500L", capacity: 1500 },
    { name: "Caixa 2.000L", capacity: 2000 },
    { name: "Caixa 3.000L", capacity: 3000 },
    { name: "Caixa 5.000L", capacity: 5000 },
    { name: "Caixa 10.000L", capacity: 10000 },
    { name: "Personalizado", capacity: 0 },
  ]

  const [selectedTankIndex, setSelectedTankIndex] = useState(1) // Padrão: 1000L
  const [customTankCapacity, setCustomTankCapacity] = useState(1000)
  const [multipleTanks, setMultipleTanks] = useState(false)
  const [secondaryTankCapacity, setSecondaryTankCapacity] = useState(500)
  const [secondaryTankLevel, setSecondaryTankLevel] = useState(45)

  // Histórico de nível da caixa
  const [tankHistory, setTankHistory] = useState([60, 75, 68, 72, 70, 65])

  // Configurações de email
  const [emailAlertsEnabled, setEmailAlertsEnabled] = useState(true)
  const [emailRecipients, setEmailRecipients] = useState([
    { email: "", enabled: true, alertLowLevel: true, alertLeak: true, alertHighUsage: true },
  ])
  const [highUsageThreshold, setHighUsageThreshold] = useState(200)
  const [emailFrequency, setEmailFrequency] = useState("immediate") // immediate, daily, weekly

  // Simulação de dados históricos
  const dailyData = [65, 85, 125, 95, 115, 125.5]
  const monthlyData = [3200, 3400, 3100, 3600, 3500, 3750.8]

  // Atualização simulada de fluxo e nível da caixa
  useEffect(() => {
    const interval = setInterval(() => {
      // Atualiza fluxo
      setCurrentFlow((prev) => {
        const variation = (Math.random() - 0.5) * 0.5
        return Number((prev + variation).toFixed(2))
      })

      // Simula variação do nível da caixa
      setTankLevel((prev) => {
        const variation = (Math.random() - 0.5) * 2
        const newLevel = prev + variation
        return Math.min(Math.max(newLevel, 0), 100) // Mantém entre 0 e 100
      })

      // Atualiza histórico a cada minuto
      if (new Date().getSeconds() === 0) {
        setTankHistory((prev) => [...prev.slice(1), tankLevel])
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [tankLevel])

  // Cálculo de custos
  const calculateCost = (volume) => {
    return (volume * costPerLiter).toFixed(2)
  }

  // Determina o status da caixa d'água
  const getTankStatus = () => {
    if (tankLevel <= tankAlertLow) return { status: "Baixo", color: "destructive" }
    if (tankLevel <= tankAlertMid) return { status: "Médio-Baixo", color: "warning" }
    if (tankLevel <= tankAlertHigh) return { status: "Médio-Alto", color: "default" }
    return { status: "Cheio", color: "success" }
  }

  // Calcula o volume atual na caixa
  const getCurrentTankVolume = () => {
    return ((tankLevel / 100) * tankCapacity).toFixed(0)
  }

  // Adiciona um novo destinatário de email
  const addEmailRecipient = () => {
    if (emailRecipients.length < 5) {
      setEmailRecipients([
        ...emailRecipients,
        { email: "", enabled: true, alertLowLevel: true, alertLeak: true, alertHighUsage: true },
      ])
    } else {
      toast({
        title: "Limite atingido",
        description: "Você pode adicionar no máximo 5 destinatários.",
        variant: "destructive",
      })
    }
  }

  // Remove um destinatário de email
  const removeEmailRecipient = (index) => {
    if (emailRecipients.length > 1) {
      setEmailRecipients(emailRecipients.filter((_, i) => i !== index))
    } else {
      toast({
        title: "Não é possível remover",
        description: "Você deve manter pelo menos um destinatário.",
        variant: "destructive",
      })
    }
  }

  // Atualiza um destinatário de email
  const updateEmailRecipient = (index, field, value) => {
    const newRecipients = [...emailRecipients]
    newRecipients[index] = { ...newRecipients[index], [field]: value }
    setEmailRecipients(newRecipients)
  }

  // Salva configurações de email
  const saveEmailSettings = () => {
    // Validação de emails
    const validEmails = emailRecipients
      .filter((r) => r.enabled)
      .every((r) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        return emailRegex.test(r.email)
      })

    if (!validEmails) {
      toast({
        title: "Erro de validação",
        description: "Por favor, verifique se todos os emails estão corretos.",
        variant: "destructive",
      })
      return
    }

    // Aqui você enviaria os dados para o servidor
    // Em um ambiente real, isso seria uma chamada API

    toast({
      title: "Configurações salvas",
      description: "As configurações de alerta por email foram atualizadas com sucesso.",
    })
  }

  // Testa o envio de email
  const testEmailAlert = () => {
    toast({
      title: "Email de teste enviado",
      description: "Um email de teste foi enviado para os destinatários configurados.",
    })
  }

  // Exporta dados para CSV
  const exportData = () => {
    // Em um ambiente real, isso geraria um arquivo CSV com os dados históricos
    toast({
      title: "Exportação iniciada",
      description: "Os dados estão sendo exportados para CSV.",
    })
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <h1 className="text-3xl font-bold mb-6">Sistema de Monitoramento de Água</h1>

      <Tabs defaultValue="dashboard" className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-7 gap-2">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="tank">Caixa d'Água</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
          <TabsTrigger value="analysis">Análise</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
          <TabsTrigger value="email">Config. Email</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        {/* Dashboard Principal */}
        <TabsContent value="dashboard" className="space-y-4">
          {/* Medições Principais */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vazão Atual</CardTitle>
                <DropletIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentFlow} L/min</div>
                <p className="text-xs text-muted-foreground">Média: 2.8 L/min</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Volume Total</CardTitle>
                <History className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalVolume.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">Desde a instalação</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consumo Hoje</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dailyUsage.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">R$ {calculateCost(dailyUsage)}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consumo Mensal</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{monthlyUsage.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">R$ {calculateCost(monthlyUsage)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Caixa d'Água - Resumo */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle>Nível da Caixa d'Água</CardTitle>
              <Tank className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="w-full">
                  <Progress value={tankLevel} className="h-4" />
                  <div className="flex justify-between mt-2">
                    <span className="text-sm text-muted-foreground">0%</span>
                    <span className="text-sm text-muted-foreground">50%</span>
                    <span className="text-sm text-muted-foreground">100%</span>
                  </div>
                </div>
                <div className="text-right min-w-[100px]">
                  <div className="text-2xl font-bold">{tankLevel.toFixed(1)}%</div>
                  <Badge variant={getTankStatus().color}>{getTankStatus().status}</Badge>
                </div>
              </div>
              <p className="text-sm mt-2">
                Volume atual: {getCurrentTankVolume()} L de {tankCapacity} L
              </p>
            </CardContent>
          </Card>

          {/* Alertas */}
          <div className="space-y-2">
            {leakDetected && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Vazamento Detectado!</AlertTitle>
                <AlertDescription>
                  Fluxo contínuo detectado nas últimas 6 horas. Verifique suas instalações.
                </AlertDescription>
              </Alert>
            )}

            {tankLevel <= tankAlertLow && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Nível Crítico na Caixa d'Água!</AlertTitle>
                <AlertDescription>
                  A caixa está com apenas {tankLevel.toFixed(1)}% da capacidade ({getCurrentTankVolume()} litros).
                </AlertDescription>
              </Alert>
            )}

            {tankLevel >= tankAlertHigh && (
              <Alert>
                <Droplets className="h-4 w-4" />
                <AlertTitle>Caixa d'Água Quase Cheia</AlertTitle>
                <AlertDescription>
                  A caixa está com {tankLevel.toFixed(1)}% da capacidade ({getCurrentTankVolume()} litros).
                </AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        {/* Caixa d'Água */}
        <TabsContent value="tank" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Visualização da Caixa */}
            <Card>
              <CardHeader>
                <CardTitle>Nível da Caixa d'Água</CardTitle>
                <CardDescription>Monitoramento em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center">
                  {/* Representação visual da caixa */}
                  <div className="w-40 h-60 border-2 border-gray-300 rounded-md relative mb-4">
                    <div
                      className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 rounded-b-sm
                        ${
                          tankLevel <= tankAlertLow
                            ? "bg-red-500"
                            : tankLevel <= tankAlertMid
                              ? "bg-yellow-500"
                              : tankLevel <= tankAlertHigh
                                ? "bg-blue-500"
                                : "bg-green-500"
                        }`}
                      style={{ height: `${tankLevel}%` }}
                    />

                    {/* Marcações de nível */}
                    <div className="absolute top-0 left-0 right-0 h-full">
                      <div className="absolute top-[10%] w-full border-t border-gray-400 border-dashed">
                        <span className="absolute -right-8 -top-2 text-xs">90%</span>
                      </div>
                      <div className="absolute top-[50%] w-full border-t border-gray-400 border-dashed">
                        <span className="absolute -right-8 -top-2 text-xs">50%</span>
                      </div>
                      <div className="absolute top-[80%] w-full border-t border-gray-400 border-dashed">
                        <span className="absolute -right-8 -top-2 text-xs">20%</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-3xl font-bold">{tankLevel.toFixed(1)}%</div>
                    <div className="text-lg">
                      {getCurrentTankVolume()} / {tankCapacity} L
                    </div>
                    <Badge className="mt-2" variant={getTankStatus().color}>
                      {getTankStatus().status}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Estatísticas e Controles */}
            <Card>
              <CardHeader>
                <CardTitle>Estatísticas da Caixa</CardTitle>
                <CardDescription>Informações e controles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Capacidade Total:</span>
                    <span className="font-medium">{tankCapacity} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Volume Atual:</span>
                    <span className="font-medium">{getCurrentTankVolume()} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Espaço Disponível:</span>
                    <span className="font-medium">{(tankCapacity - Number(getCurrentTankVolume())).toFixed(0)} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <Badge variant={getTankStatus().color}>{getTankStatus().status}</Badge>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-2">Alertas da Caixa</h4>
                  <div className="flex items-center justify-between mb-2">
                    <span>Ativar alertas</span>
                    <Button
                      variant={tankAlertsEnabled ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTankAlertsEnabled(!tankAlertsEnabled)}
                    >
                      {tankAlertsEnabled ? <Bell className="h-4 w-4 mr-1" /> : <BellOff className="h-4 w-4 mr-1" />}
                      {tankAlertsEnabled ? "Ativado" : "Desativado"}
                    </Button>
                  </div>

                  <div className="space-y-4 mt-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Alerta de Nível Baixo: {tankAlertLow}%</span>
                      </div>
                      <Slider
                        value={[tankAlertLow]}
                        min={5}
                        max={40}
                        step={5}
                        onValueChange={(value) => setTankAlertLow(value[0])}
                        disabled={!tankAlertsEnabled}
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Alerta de Nível Médio: {tankAlertMid}%</span>
                      </div>
                      <Slider
                        value={[tankAlertMid]}
                        min={40}
                        max={70}
                        step={5}
                        onValueChange={(value) => setTankAlertMid(value[0])}
                        disabled={!tankAlertsEnabled}
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Alerta de Nível Alto: {tankAlertHigh}%</span>
                      </div>
                      <Slider
                        value={[tankAlertHigh]}
                        min={70}
                        max={95}
                        step={5}
                        onValueChange={(value) => setTankAlertHigh(value[0])}
                        disabled={!tankAlertsEnabled}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Histórico de Nível */}
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Nível</CardTitle>
              <CardDescription>Variação nas últimas 24 horas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                <div className="flex items-end justify-between h-full">
                  {tankHistory.map((value, index) => (
                    <div
                      key={index}
                      className={`w-12 rounded-t ${
                        value <= tankAlertLow
                          ? "bg-red-500"
                          : value <= tankAlertMid
                            ? "bg-yellow-500"
                            : value <= tankAlertHigh
                              ? "bg-blue-500"
                              : "bg-green-500"
                      }`}
                      style={{ height: `${value}%` }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                <span>-24h</span>
                <span>-18h</span>
                <span>-12h</span>
                <span>-8h</span>
                <span>-4h</span>
                <span>Agora</span>
              </div>
            </CardContent>
          </Card>

          {/* Caixa Secundária (quando ativada) */}
          {multipleTanks && (
            <Card>
              <CardHeader>
                <CardTitle>Caixa d'Água Secundária</CardTitle>
                <CardDescription>Monitoramento da caixa adicional</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="w-full">
                    <Progress value={secondaryTankLevel} className="h-4" />
                    <div className="flex justify-between mt-2">
                      <span className="text-sm text-muted-foreground">0%</span>
                      <span className="text-sm text-muted-foreground">50%</span>
                      <span className="text-sm text-muted-foreground">100%</span>
                    </div>
                  </div>
                  <div className="text-right min-w-[100px]">
                    <div className="text-2xl font-bold">{secondaryTankLevel.toFixed(1)}%</div>
                    <Badge
                      variant={
                        secondaryTankLevel <= tankAlertLow
                          ? "destructive"
                          : secondaryTankLevel <= tankAlertMid
                            ? "warning"
                            : secondaryTankLevel <= tankAlertHigh
                              ? "default"
                              : "success"
                      }
                    >
                      {secondaryTankLevel <= tankAlertLow
                        ? "Baixo"
                        : secondaryTankLevel <= tankAlertMid
                          ? "Médio-Baixo"
                          : secondaryTankLevel <= tankAlertHigh
                            ? "Médio-Alto"
                            : "Cheio"}
                    </Badge>
                  </div>
                </div>
                <p className="text-sm mt-2">
                  Volume atual: {((secondaryTankLevel / 100) * secondaryTankCapacity).toFixed(0)} L de{" "}
                  {secondaryTankCapacity} L
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Histórico */}
        <TabsContent value="history" className="space-y-4">
          <div className="flex justify-end mb-2">
            <Button variant="outline" size="sm" onClick={exportData}>
              <Download className="h-4 w-4 mr-2" />
              Exportar Dados
            </Button>
          </div>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Histórico de Consumo</CardTitle>
                <CardDescription>Últimos 6 dias de consumo</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <BarChart className="h-4 w-4 mr-1" />
                  Barras
                </Button>
                <Button variant="outline" size="sm">
                  <LineChart className="h-4 w-4 mr-1" />
                  Linha
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                {/* Aqui você pode adicionar um gráfico de barras ou linha */}
                <div className="flex items-end justify-between h-full">
                  {dailyData.map((value, index) => (
                    <div
                      key={index}
                      className="w-12 bg-primary rounded-t"
                      style={{ height: `${(value / Math.max(...dailyData)) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                <span>Seg</span>
                <span>Ter</span>
                <span>Qua</span>
                <span>Qui</span>
                <span>Sex</span>
                <span>Hoje</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Consumo Mensal</CardTitle>
                <CardDescription>Últimos 6 meses</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <BarChart className="h-4 w-4 mr-1" />
                  Barras
                </Button>
                <Button variant="outline" size="sm">
                  <LineChart className="h-4 w-4 mr-1" />
                  Linha
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                <div className="flex items-end justify-between h-full">
                  {monthlyData.map((value, index) => (
                    <div
                      key={index}
                      className="w-12 bg-primary rounded-t"
                      style={{ height: `${(value / Math.max(...monthlyData)) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                <span>Jan</span>
                <span>Fev</span>
                <span>Mar</span>
                <span>Abr</span>
                <span>Mai</span>
                <span>Jun</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Análise */}
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Análise de Consumo</CardTitle>
                <CardDescription>Comparação com média histórica</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Consumo Atual</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>{dailyUsage.toFixed(2)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Média Diária</span>
                    <Badge>120 L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Variação</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>
                      {(((dailyUsage - 120) / 120) * 100).toFixed(1)}%
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Previsão de Consumo</CardTitle>
                <CardDescription>Baseado no histórico</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Previsão Mensal</span>
                    <Badge>{(dailyUsage * 30).toFixed(0)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Custo Estimado</span>
                    <Badge variant="outline">R$ {calculateCost(dailyUsage * 30)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Eficiência de Consumo</CardTitle>
              <CardDescription>Comparação com metas estabelecidas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Meta Mensal: {monthlyTarget} L</span>
                    <span>{((monthlyUsage / monthlyTarget) * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={(monthlyUsage / monthlyTarget) * 100} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span>Consumo por Pessoa: 125 L/dia</span>
                    <Badge variant={125 > 110 ? "destructive" : "success"}>
                      {125 > 110 ? "Acima da média" : "Abaixo da média"}
                    </Badge>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span>Economia Estimada</span>
                    <span>
                      R${" "}
                      {((monthlyTarget - monthlyUsage) * costPerLiter > 0
                        ? (monthlyTarget - monthlyUsage) * costPerLiter
                        : 0
                      ).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alertas */}
        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração de Alertas</CardTitle>
              <CardDescription>Defina limites para notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Alerta de Consumo Diário</span>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={highUsageThreshold}
                    onChange={(e) => setHighUsageThreshold(Number(e.target.value))}
                    className="w-20"
                  />
                  <span>L</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Vazamento</span>
                <Badge>6 horas de fluxo contínuo</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Meta Mensal</span>
                <Badge>90% da meta</Badge>
              </div>

              <div className="pt-2 border-t mt-2">
                <h4 className="font-medium mb-2">Alertas da Caixa d'Água</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span>Nível Baixo</span>
                    <Badge variant="destructive">{tankAlertLow}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Nível Médio</span>
                    <Badge variant="warning">{tankAlertMid}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Nível Alto</span>
                    <Badge variant="success">{tankAlertHigh}%</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Histórico de Alertas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tankLevel <= tankAlertLow && (
                  <Alert variant="destructive">
                    <Tank className="h-4 w-4" />
                    <AlertTitle>Nível Crítico na Caixa d'Água</AlertTitle>
                    <AlertDescription>Apenas {tankLevel.toFixed(1)}% de capacidade - Agora</AlertDescription>
                  </Alert>
                )}

                {leakDetected && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Vazamento Detectado</AlertTitle>
                    <AlertDescription>Fluxo contínuo detectado - 28/02/2024 14:30</AlertDescription>
                  </Alert>
                )}

                <Alert>
                  <Tank className="h-4 w-4" />
                  <AlertTitle>Nível Médio na Caixa d'Água</AlertTitle>
                  <AlertDescription>50% de capacidade atingida - 28/02/2024 10:15</AlertDescription>
                </Alert>

                <Alert>
                  <Target className="h-4 w-4" />
                  <AlertTitle>Meta Mensal Próxima</AlertTitle>
                  <AlertDescription>90% da meta mensal atingida - 27/02/2024 18:45</AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuração de Email */}
        <TabsContent value="email" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração de Alertas por Email</CardTitle>
              <CardDescription>Configure destinatários e tipos de alertas</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="email-alerts" checked={emailAlertsEnabled} onCheckedChange={setEmailAlertsEnabled} />
                <Label htmlFor="email-alerts">Ativar alertas por email</Label>
              </div>

              <div className="pt-4">
                <h3 className="text-lg font-medium mb-2">Destinatários</h3>

                {emailRecipients.map((recipient, index) => (
                  <div key={index} className="border rounded-md p-4 mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Destinatário {index + 1}</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeEmailRecipient(index)}
                        disabled={emailRecipients.length === 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Switch
                          id={`recipient-enabled-${index}`}
                          checked={recipient.enabled}
                          onCheckedChange={(checked) => updateEmailRecipient(index, "enabled", checked)}
                        />
                        <Label htmlFor={`recipient-enabled-${index}`}>Ativo</Label>
                      </div>

                      <div className="grid w-full items-center gap-1.5">
                        <Label htmlFor={`email-${index}`}>Email</Label>
                        <Input
                          type="email"
                          id={`email-${index}`}
                          placeholder="exemplo@email.com"
                          value={recipient.email}
                          onChange={(e) => updateEmailRecipient(index, "email", e.target.value)}
                          disabled={!recipient.enabled}
                        />
                      </div>

                      <div className="space-y-2">
                        <h5 className="text-sm font-medium">Tipos de Alerta</h5>
                        <div className="flex items-center space-x-2">
                          <Switch
                            id={`low-level-${index}`}
                            checked={recipient.alertLowLevel}
                            onCheckedChange={(checked) => updateEmailRecipient(index, "alertLowLevel", checked)}
                            disabled={!recipient.enabled}
                          />
                          <Label htmlFor={`low-level-${index}`}>Nível baixo na caixa d'água</Label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            id={`leak-${index}`}
                            checked={recipient.alertLeak}
                            onCheckedChange={(checked) => updateEmailRecipient(index, "alertLeak", checked)}
                            disabled={!recipient.enabled}
                          />
                          <Label htmlFor={`leak-${index}`}>Detecção de vazamento</Label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            id={`high-usage-${index}`}
                            checked={recipient.alertHighUsage}
                            onCheckedChange={(checked) => updateEmailRecipient(index, "alertHighUsage", checked)}
                            disabled={!recipient.enabled}
                          />
                          <Label htmlFor={`high-usage-${index}`}>Consumo elevado</Label>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                <Button
                  variant="outline"
                  onClick={addEmailRecipient}
                  disabled={emailRecipients.length >= 5 || !emailAlertsEnabled}
                  className="w-full"
                >
                  Adicionar Destinatário
                </Button>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-2">Configurações Adicionais</h3>

                <div className="space-y-4">
                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="usage-threshold">Limite de consumo diário (L)</Label>
                    <Input
                      type="number"
                      id="usage-threshold"
                      value={highUsageThreshold}
                      onChange={(e) => setHighUsageThreshold(Number(e.target.value))}
                      disabled={!emailAlertsEnabled}
                    />
                    <p className="text-sm text-muted-foreground">
                      Um alerta será enviado quando o consumo diário ultrapassar este valor
                    </p>
                  </div>

                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="email-frequency">Frequência de relatórios</Label>
                    <select
                      id="email-frequency"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={emailFrequency}
                      onChange={(e) => setEmailFrequency(e.target.value)}
                      disabled={!emailAlertsEnabled}
                    >
                      <option value="immediate">Imediato (apenas alertas)</option>
                      <option value="daily">Relatório Diário</option>
                      <option value="weekly">Relatório Semanal</option>
                    </select>
                    <p className="text-sm text-muted-foreground">
                      Define a frequência de envio de relatórios de consumo
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={testEmailAlert} disabled={!emailAlertsEnabled}>
                  Enviar Email de Teste
                </Button>
                <Button onClick={saveEmailSettings}>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configurações */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Sistema</CardTitle>
              <CardDescription>Ajuste os parâmetros do medidor</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="calibration-factor">Fator de Calibração</Label>
                  <div className="flex items-center gap-2">
                    <Input type="number" id="calibration-factor" value="7.5" step="0.1" min="0.1" />
                    <span>pulsos/L</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Fator de calibração do sensor de fluxo (YF-S201 = 7.5 pulsos por litro)
                  </p>
                </div>

                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="cost-per-liter">Custo por m³</Label>
                  <div className="flex items-center gap-2">
                    <span>R$</span>
                    <Input
                      type="number"
                      id="cost-per-liter"
                      value={(costPerLiter * 1000).toFixed(2)}
                      step="0.01"
                      min="0"
                      onChange={(e) => setCostPerLiter(Number(e.target.value) / 1000)}
                    />
                  </div>
                </div>

                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="monthly-target">Meta Mensal</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      id="monthly-target"
                      value={monthlyTarget}
                      step="100"
                      min="0"
                      onChange={(e) => setMonthlyTarget(Number(e.target.value))}
                    />
                    <span>L</span>
                  </div>
                </div>

                <Separator />

                <div className="pt-2">
                  <h4 className="font-medium mb-2">Configurações da Caixa d'Água</h4>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm mb-1 block">Selecione o modelo da caixa:</Label>
                      <select
                        className="w-full h-9 rounded-md border border-input bg-background px-3 py-1"
                        value={selectedTankIndex}
                        onChange={(e) => {
                          const index = Number.parseInt(e.target.value)
                          setSelectedTankIndex(index)
                          if (index < standardTanks.length - 1) {
                            setTankCapacity(standardTanks[index].capacity)
                          }
                        }}
                      >
                        {standardTanks.map((tank, index) => (
                          <option key={index} value={index}>
                            {tank.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    {selectedTankIndex === standardTanks.length - 1 && (
                      <div>
                        <Label className="text-sm mb-1 block">Capacidade personalizada:</Label>
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            value={customTankCapacity}
                            onChange={(e) => {
                              const value = Number(e.target.value)
                              setCustomTankCapacity(value)
                              setTankCapacity(value)
                            }}
                            className="w-full h-9 rounded-md border border-input bg-background px-3 py-1"
                            min="100"
                            max="50000"
                            step="100"
                          />
                          <span>L</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center space-x-2">
                      <Switch id="multipleTanks" checked={multipleTanks} onCheckedChange={setMultipleTanks} />
                      <Label htmlFor="multipleTanks">Configurar múltiplas caixas</Label>
                    </div>

                    {multipleTanks && (
                      <div className="space-y-2 border rounded-md p-3 bg-muted/20">
                        <h5 className="font-medium text-sm">Caixa Secundária</h5>
                        <div>
                          <Label className="text-sm mb-1 block">Capacidade:</Label>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              value={secondaryTankCapacity}
                              onChange={(e) => setSecondaryTankCapacity(Number(e.target.value))}
                              className="w-full h-9 rounded-md border border-input bg-background px-3 py-1"
                              min="100"
                              max="50000"
                              step="100"
                            />
                            <span>L</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Restaurar Padrões
                </Button>
                <Button>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

