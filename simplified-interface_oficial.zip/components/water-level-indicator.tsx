"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function WaterLevelIndicator() {
  const [waterLevel, setWaterLevel] = useState(75)

  useEffect(() => {
    // Simulação de dados - em um ambiente real, isso viria da API
    const fetchData = () => {
      // Simular variação de nível
      const newLevel = Math.max(0, Math.min(100, waterLevel + (Math.random() * 6 - 3)))
      setWaterLevel(Math.round(newLevel))
    }

    fetchData()
    const interval = setInterval(fetchData, 30000) // Atualiza a cada 30 segundos

    return () => clearInterval(interval)
  }, [waterLevel])

  // Determinar cor baseada no nível
  const getWaterColor = () => {
    if (waterLevel < 20) return "bg-red-500"
    if (waterLevel < 40) return "bg-yellow-500"
    return "bg-blue-500"
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Nível da Caixa d'Água</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold">{waterLevel}%</span>
          </div>

          {/* Indicador visual de nível */}
          <div className="relative h-40 w-full border-2 border-gray-300 rounded-md overflow-hidden">
            <div
              className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 ${getWaterColor()}`}
              style={{ height: `${waterLevel}%` }}
            ></div>

            {/* Marcadores de nível */}
            <div className="absolute top-0 left-0 right-0 h-full">
              <div className="relative h-full">
                <div className="absolute top-[30%] w-full border-t border-dashed border-gray-400 flex justify-end">
                  <span className="bg-white px-1 text-xs mr-1">70%</span>
                </div>
                <div className="absolute top-[60%] w-full border-t border-dashed border-gray-400 flex justify-end">
                  <span className="bg-white px-1 text-xs mr-1">30%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Legenda de níveis */}
          <div className="grid grid-cols-3 text-xs">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
              <span>Baixo (0-29%)</span>
            </div>
            <div className="flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
              <span>Médio (30-69%)</span>
            </div>
            <div className="flex items-center justify-end">
              <div className="w-3 h-3 rounded-full bg-blue-500 mr-1"></div>
              <span>Alto (70-100%)</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

