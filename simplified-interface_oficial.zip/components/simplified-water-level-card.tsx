"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function SimplifiedWaterLevelCard() {
  const [waterLevel, setWaterLevel] = useState(75)

  useEffect(() => {
    // Simulação de dados - em um ambiente real, isso viria da API
    const fetchData = () => {
      // Simular variação de nível
      const newLevel = Math.max(0, Math.min(100, waterLevel + (Math.random() * 6 - 3)))
      setWaterLevel(Math.round(newLevel))
    }

    fetchData()
    const interval = setInterval(fetchData, 30000) // Atualiza a cada 30 segundos

    return () => clearInterval(interval)
  }, [waterLevel])

  // Determinar cor baseada no nível
  const getColorClass = () => {
    if (waterLevel < 20) return "text-red-500"
    if (waterLevel < 40) return "text-orange-500"
    return "text-green-500"
  }

  // Determinar o status do nível
  const getWaterLevelStatus = () => {
    if (waterLevel >= 70) return "Alto"
    if (waterLevel >= 30) return "Médio"
    return "Baixo"
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Nível da Caixa d'Água</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <span className={`text-2xl font-bold ${getColorClass()}`}>{waterLevel}%</span>
            <span
              className={`px-2 py-1 rounded text-sm font-medium ${
                waterLevel >= 70
                  ? "bg-green-100 text-green-800"
                  : waterLevel >= 30
                    ? "bg-yellow-100 text-yellow-800"
                    : "bg-red-100 text-red-800"
              }`}
            >
              {getWaterLevelStatus()}
            </span>
          </div>
          <Progress value={waterLevel} className="h-4" />

          {/* Indicadores de nível */}
          <div className="grid grid-cols-3 text-xs">
            <div className="flex flex-col">
              <span className="text-red-500 font-medium">Baixo</span>
              <span className="text-muted-foreground">0-29%</span>
            </div>
            <div className="flex flex-col text-center">
              <span className="text-yellow-500 font-medium">Médio</span>
              <span className="text-muted-foreground">30-69%</span>
            </div>
            <div className="flex flex-col text-right">
              <span className="text-green-500 font-medium">Alto</span>
              <span className="text-muted-foreground">70-100%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

