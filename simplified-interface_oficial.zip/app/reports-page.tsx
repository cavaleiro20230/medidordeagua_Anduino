import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ReportsPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Sistema de Monitoramento</h1>
          <nav className="hidden sm:flex space-x-4">
            <Link href="/simplified-dashboard" className="text-sm font-medium hover:underline">
              Início
            </Link>
            <Link href="/reports-page" className="text-sm font-medium hover:underline font-bold underline">
              Relatórios
            </Link>
            <Link href="/settings-page" className="text-sm font-medium hover:underline">
              Configurações
            </Link>
          </nav>
          <Button variant="outline" size="sm" className="sm:hidden">
            Menu
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Relatórios</h2>
          <p className="text-muted-foreground">Visualize o histórico de consumo e níveis da sua caixa d'água</p>
        </div>

        <Tabs defaultValue="daily" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="daily">Diário</TabsTrigger>
            <TabsTrigger value="weekly">Semanal</TabsTrigger>
            <TabsTrigger value="monthly">Mensal</TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Consumo Diário</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Gráfico de consumo diário</p>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas do Dia</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Consumo Total</span>
                      <span className="font-medium">120 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Nível Médio</span>
                      <span className="font-medium">65%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Nível Mínimo</span>
                      <span className="font-medium">45%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Nível Máximo</span>
                      <span className="font-medium">85%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Alertas do Dia</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                      <div className="font-medium text-yellow-800">Consumo acima da média</div>
                      <div className="text-sm text-yellow-600">Hoje, 14:30</div>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                      <div className="font-medium text-green-800">Nível normalizado</div>
                      <div className="text-sm text-green-600">Hoje, 16:45</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="weekly" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Consumo Semanal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Gráfico de consumo semanal</p>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas da Semana</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Consumo Total</span>
                      <span className="font-medium">840 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Média Diária</span>
                      <span className="font-medium">120 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Dia de Maior Consumo</span>
                      <span className="font-medium">Segunda (150 litros)</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Dia de Menor Consumo</span>
                      <span className="font-medium">Domingo (90 litros)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Comparativo</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Semana Anterior</span>
                      <span className="font-medium">780 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Variação</span>
                      <span className="font-medium text-red-500">+7.7%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Média Mensal</span>
                      <span className="font-medium">800 litros/semana</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Consumo Mensal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Gráfico de consumo mensal</p>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas do Mês</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Consumo Total</span>
                      <span className="font-medium">3.600 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Média Diária</span>
                      <span className="font-medium">120 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Custo Estimado</span>
                      <span className="font-medium">R$ 45,00</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Comparativo Anual</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Mês Anterior</span>
                      <span className="font-medium">3.400 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Variação</span>
                      <span className="font-medium text-red-500">+5.9%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Mesmo mês (ano anterior)</span>
                      <span className="font-medium">3.200 litros</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Variação Anual</span>
                      <span className="font-medium text-red-500">+12.5%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Button>Exportar Relatório</Button>
        </div>
      </main>

      <footer className="border-t">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          © 2024 Sistema de Monitoramento de Água. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  )
}

