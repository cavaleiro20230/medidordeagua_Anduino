"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SettingsPage() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const [lowLevelAlert, setLowLevelAlert] = useState(20)
  const [highLevelAlert, setHighLevelAlert] = useState(90)
  const [dailyLimit, setDailyLimit] = useState(150)
  const [updateInterval, setUpdateInterval] = useState(30)

  const handleSaveGeneral = () => {
    alert("Configurações gerais salvas com sucesso!")
  }

  const handleSaveAlerts = () => {
    alert("Configurações de alertas salvas com sucesso!")
  }

  const handleSaveSystem = () => {
    alert("Configurações do sistema salvas com sucesso!")
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Sistema de Monitoramento</h1>
          <nav className="hidden sm:flex space-x-4">
            <Link href="/simplified-dashboard" className="text-sm font-medium hover:underline">
              Início
            </Link>
            <Link href="/reports-page" className="text-sm font-medium hover:underline">
              Relatórios
            </Link>
            <Link href="/settings-page" className="text-sm font-medium hover:underline font-bold underline">
              Configurações
            </Link>
          </nav>
          <Button variant="outline" size="sm" className="sm:hidden">
            Menu
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Configurações</h2>
          <p className="text-muted-foreground">
            Personalize o sistema de monitoramento de acordo com suas necessidades
          </p>
        </div>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="general">Geral</TabsTrigger>
            <TabsTrigger value="alerts">Alertas</TabsTrigger>
            <TabsTrigger value="system">Sistema</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurações Gerais</CardTitle>
                <CardDescription>Configure as preferências básicas do sistema</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="tank-name">Nome da Caixa d'Água</Label>
                  <Input id="tank-name" defaultValue="Caixa Principal" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tank-capacity">Capacidade (litros)</Label>
                  <Input id="tank-capacity" type="number" defaultValue="1000" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="water-cost">Custo por 1000 litros (R$)</Label>
                  <Input id="water-cost" type="number" defaultValue="12.50" step="0.01" />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications" className="cursor-pointer">
                    Notificações
                  </Label>
                  <Switch id="notifications" checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="language">Idioma</Label>
                  <Select defaultValue="pt-BR">
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Selecione um idioma" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                      <SelectItem value="en-US">English (US)</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveGeneral}>Salvar Alterações</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Alertas</CardTitle>
                <CardDescription>Defina quando você deseja receber alertas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="low-level">Alerta de Nível Baixo (%)</Label>
                  <Input
                    id="low-level"
                    type="number"
                    value={lowLevelAlert}
                    onChange={(e) => setLowLevelAlert(Number(e.target.value))}
                    min="0"
                    max="100"
                  />
                  <p className="text-xs text-muted-foreground">
                    Você receberá um alerta quando o nível estiver abaixo deste valor
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="high-level">Alerta de Nível Alto (%)</Label>
                  <Input
                    id="high-level"
                    type="number"
                    value={highLevelAlert}
                    onChange={(e) => setHighLevelAlert(Number(e.target.value))}
                    min="0"
                    max="100"
                  />
                  <p className="text-xs text-muted-foreground">
                    Você receberá um alerta quando o nível estiver acima deste valor
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="daily-limit">Limite Diário de Consumo (litros)</Label>
                  <Input
                    id="daily-limit"
                    type="number"
                    value={dailyLimit}
                    onChange={(e) => setDailyLimit(Number(e.target.value))}
                    min="0"
                  />
                  <p className="text-xs text-muted-foreground">
                    Você receberá um alerta quando o consumo diário ultrapassar este valor
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="email-alerts" className="cursor-pointer">
                    Alertas por E-mail
                  </Label>
                  <Switch id="email-alerts" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="sms-alerts" className="cursor-pointer">
                    Alertas por SMS
                  </Label>
                  <Switch id="sms-alerts" />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="app-alerts" className="cursor-pointer">
                    Alertas no Aplicativo
                  </Label>
                  <Switch id="app-alerts" defaultChecked />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveAlerts}>Salvar Alertas</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurações do Sistema</CardTitle>
                <CardDescription>Ajuste as configurações técnicas do sistema</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="update-interval">Intervalo de Atualização (segundos)</Label>
                  <Input
                    id="update-interval"
                    type="number"
                    value={updateInterval}
                    onChange={(e) => setUpdateInterval(Number(e.target.value))}
                    min="5"
                  />
                  <p className="text-xs text-muted-foreground">Frequência com que os dados são atualizados</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sensor-calibration">Calibração do Sensor (%)</Label>
                  <Input id="sensor-calibration" type="number" defaultValue="0" min="-10" max="10" step="0.1" />
                  <p className="text-xs text-muted-foreground">Ajuste fino para calibrar o sensor de nível</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="data-retention">Retenção de Dados</Label>
                  <Select defaultValue="90">
                    <SelectTrigger id="data-retention">
                      <SelectValue placeholder="Selecione um período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 dias</SelectItem>
                      <SelectItem value="90">90 dias</SelectItem>
                      <SelectItem value="180">6 meses</SelectItem>
                      <SelectItem value="365">1 ano</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Por quanto tempo os dados históricos serão armazenados
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="debug-mode" className="cursor-pointer">
                    Modo de Depuração
                  </Label>
                  <Switch id="debug-mode" />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-update" className="cursor-pointer">
                    Atualizações Automáticas
                  </Label>
                  <Switch id="auto-update" defaultChecked />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Redefinir Padrões</Button>
                <Button onClick={handleSaveSystem}>Salvar Configurações</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Informações do Sistema</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Versão do Software</span>
                  <span className="font-medium">1.2.0</span>
                </div>
                <div className="flex justify-between">
                  <span>Versão do Firmware</span>
                  <span className="font-medium">0.9.5</span>
                </div>
                <div className="flex justify-between">
                  <span>Último Backup</span>
                  <span className="font-medium">10/04/2024 08:30</span>
                </div>
                <div className="flex justify-between">
                  <span>Status do Sistema</span>
                  <span className="font-medium text-green-500">Online</span>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Fazer Backup</Button>
                <Button variant="outline">Verificar Atualizações</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          © 2024 Sistema de Monitoramento de Água. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  )
}

