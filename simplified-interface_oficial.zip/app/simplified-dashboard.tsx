import Link from "next/link"
import { Button } from "@/components/ui/button"
import SimplifiedWaterLevelCard from "@/components/simplified-water-level-card"
import WaterLevelIndicator from "@/components/water-level-indicator"
import ConsumptionCard from "@/components/consumption-card"
import CostCard from "@/components/cost-card"

export default function SimplifiedDashboard() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Sistema de Monitoramento</h1>
          <nav className="hidden sm:flex space-x-4">
            <Link href="#" className="text-sm font-medium hover:underline">
              Início
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline">
              Relatórios
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline">
              Configurações
            </Link>
          </nav>
          <Button variant="outline" size="sm" className="sm:hidden">
            Menu
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <SimplifiedWaterLevelCard />
          <WaterLevelIndicator />
          <ConsumptionCard />
          <CostCard />
        </div>
      </main>

      <footer className="border-t">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          © 2024 Sistema de Monitoramento de Água. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  )
}

