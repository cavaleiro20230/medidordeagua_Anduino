import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function SimplifiedInterface() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Sistema de Monitoramento</h1>
          <nav className="hidden sm:flex space-x-4">
            <Link href="#" className="text-sm font-medium hover:underline">
              Início
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline">
              Relatórios
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline">
              Configurações
            </Link>
          </nav>
          <Button variant="outline" size="sm" className="sm:hidden">
            Menu
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Nível da Água</CardTitle>
              <CardDescription>Monitoramento em tempo real</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 bg-muted rounded-md flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl font-bold">75%</div>
                  <div className="text-sm text-muted-foreground">Nível atual</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Ver detalhes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Qualidade da Água</CardTitle>
              <CardDescription>Parâmetros principais</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>pH</span>
                  <span className="font-medium">7.2</span>
                </div>
                <div className="flex justify-between">
                  <span>Temperatura</span>
                  <span className="font-medium">22°C</span>
                </div>
                <div className="flex justify-between">
                  <span>Turbidez</span>
                  <span className="font-medium">Baixa</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Ver detalhes
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Alertas</CardTitle>
              <CardDescription>Últimas notificações</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-3 bg-muted rounded-md">
                  <div className="font-medium">Nível baixo</div>
                  <div className="text-sm text-muted-foreground">Hoje, 10:45</div>
                </div>
                <div className="p-3 bg-muted rounded-md">
                  <div className="font-medium">Manutenção programada</div>
                  <div className="text-sm text-muted-foreground">Amanhã, 09:00</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Ver todos
              </Button>
            </CardFooter>
          </Card>
        </div>
      </main>

      <footer className="border-t">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          © 2024 Sistema de Monitoramento de Água. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  )
}

