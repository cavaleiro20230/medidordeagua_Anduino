import { Button } from "@/components/ui/button"

export default function SimplifiedHomePage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Sistema de Monitoramento</h1>
          <Button variant="outline" size="sm">
            Entrar
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto text-center py-12">
          <h2 className="text-3xl font-bold mb-4">Monitoramento de Caixa d'Água</h2>
          <p className="text-lg mb-8">
            Acompanhe o nível e consumo da sua caixa d'água em tempo real com nosso sistema simplificado.
          </p>
          <Button>Começar agora</Button>
        </div>
      </main>

      <footer className="border-t">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          © 2024 Sistema de Monitoramento de Água. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  )
}

