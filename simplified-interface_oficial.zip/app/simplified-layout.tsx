import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "Monitoramento de Caixa d'Água",
  description: "Sistema simplificado de monitoramento de caixa d'água",
}

export default function SimplifiedLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}

