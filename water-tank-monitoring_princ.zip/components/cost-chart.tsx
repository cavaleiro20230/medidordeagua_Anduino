"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function CostChart() {
  const [activeTab, setActiveTab] = useState("weekly")
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Gerar dados simulados com base na aba selecionada
    if (activeTab === "weekly") {
      // Dados dos últimos 7 dias
      const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]
      const dailyData = Array.from({ length: 7 }, (_, i) => {
        const dayIndex = (new Date().getDay() - i + 7) % 7
        return {
          time: days[dayIndex],
          custo: Number.parseFloat((Math.random() * 2 + 1).toFixed(2)),
        }
      }).reverse()
      setData(dailyData)
    } else {
      // Dados dos últimos 12 meses
      const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
      const monthlyData = Array.from({ length: 12 }, (_, i) => {
        const monthIndex = (new Date().getMonth() - i + 12) % 12
        return {
          time: months[monthIndex],
          custo: Number.parseFloat((Math.random() * 30 + 20).toFixed(2)),
        }
      }).reverse()
      setData(monthlyData)
    }
  }, [activeTab])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Custos</CardTitle>
        <CardDescription>Visualize os custos ao longo do tempo</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="weekly" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="weekly">Semanal</TabsTrigger>
            <TabsTrigger value="yearly">Anual</TabsTrigger>
          </TabsList>
          <TabsContent value="weekly" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="R$" />
                <Tooltip formatter={(value) => [`R$ ${value}`, "Custo"]} />
                <Bar dataKey="custo" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
          <TabsContent value="yearly" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="R$" />
                <Tooltip formatter={(value) => [`R$ ${value}`, "Custo"]} />
                <Bar dataKey="custo" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

