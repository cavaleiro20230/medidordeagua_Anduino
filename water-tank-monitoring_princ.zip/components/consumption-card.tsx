"use client"

import { useState, useEffect, useRef } from "react"
import { TrendingUp, TrendingDown } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ConsumptionCard() {
  const [consumption, setConsumption] = useState(120)
  const [trend, setTrend] = useState(0)
  const [lastUpdated, setLastUpdated] = useState("")
  const previousConsumption = useRef(consumption)

  useEffect(() => {
    // Simulação de dados - em um ambiente real, isso viria da API
    const fetchData = () => {
      // Simular variação de consumo
      const newConsumption = Math.max(0, consumption + (Math.random() * 10 - 5))
      setConsumption(Math.round(newConsumption))

      // Calcular tendência (comparação com valor anterior)
      const newTrend = Math.round(newConsumption - previousConsumption.current)
      setTrend(newTrend)
      previousConsumption.current = newConsumption

      setLastUpdated(new Date().toLocaleTimeString())
    }

    fetchData()
    const interval = setInterval(fetchData, 60000) // Atualiza a cada minuto

    return () => clearInterval(interval)
  }, [consumption])

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Consumo Diário</CardTitle>
        <CardDescription>Atualizado: {lastUpdated}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold">{consumption} L</span>
            <div className="flex items-center">
              {trend > 0 ? (
                <TrendingUp className="mr-1 h-4 w-4 text-red-500" />
              ) : (
                <TrendingDown className="mr-1 h-4 w-4 text-green-500" />
              )}
              <span className={trend > 0 ? "text-red-500" : "text-green-500"}>{Math.abs(trend)}L</span>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">Média semanal: 115L por dia</div>
        </div>
      </CardContent>
    </Card>
  )
}

