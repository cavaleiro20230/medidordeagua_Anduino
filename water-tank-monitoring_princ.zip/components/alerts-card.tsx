"use client"

import { useState, useEffect } from "react"
import { AlertTriangle, CheckCircle2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

export default function AlertsCard() {
  const [alerts, setAlerts] = useState<{ id: number; type: string; message: string; date: string }[]>([])

  useEffect(() => {
    // Simulação de alertas - em um ambiente real, isso viria da API
    setAlerts([
      {
        id: 1,
        type: "warning",
        message: "Nível de água abaixo de 30%",
        date: "Hoje, 08:45",
      },
      {
        id: 2,
        type: "info",
        message: "Consumo acima da média nas últimas 24 horas",
        date: "Ontem, 19:20",
      },
      {
        id: 3,
        type: "success",
        message: "Manutenção do sistema concluída com sucesso",
        date: "15/06/2023, 14:30",
      },
    ])
  }, [])

  const dismissAlert = (id: number) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alertas e Notificações</CardTitle>
        <CardDescription>Últimos alertas do sistema</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <CheckCircle2 className="h-10 w-10 text-green-500 mb-2" />
              <h3 className="font-medium">Nenhum alerta ativo</h3>
              <p className="text-sm text-muted-foreground">O sistema está funcionando normalmente</p>
            </div>
          ) : (
            alerts.map((alert) => (
              <Alert key={alert.id} variant={alert.type === "warning" ? "destructive" : "default"}>
                <AlertTriangle className="h-4 w-4" />
                <div className="flex-1">
                  <AlertTitle>
                    {alert.type === "warning" ? "Atenção" : alert.type === "success" ? "Sucesso" : "Informação"}
                  </AlertTitle>
                  <AlertDescription className="flex justify-between items-start">
                    <div>
                      <p>{alert.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">{alert.date}</p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => dismissAlert(alert.id)}>
                      Dispensar
                    </Button>
                  </AlertDescription>
                </div>
              </Alert>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}

