"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { signOut } from "next-auth/react"
import { DropletsIcon as WaterDropIcon, Settings, LogOut, Bell, Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function DashboardHeader() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/dashboard" className="mr-6 flex items-center space-x-2">
            <WaterDropIcon className="h-6 w-6 text-blue-600" />
            <span className="hidden font-bold sm:inline-block">AquaMonitor</span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link
              href="/dashboard"
              className={`transition-colors hover:text-foreground/80 ${
                pathname === "/dashboard" ? "text-foreground" : "text-foreground/60"
              }`}
            >
              Dashboard
            </Link>
            <Link
              href="/dashboard/history"
              className={`transition-colors hover:text-foreground/80 ${
                pathname === "/dashboard/history" ? "text-foreground" : "text-foreground/60"
              }`}
            >
              Histórico
            </Link>
            <Link
              href="/dashboard/settings"
              className={`transition-colors hover:text-foreground/80 ${
                pathname === "/dashboard/settings" ? "text-foreground" : "text-foreground/60"
              }`}
            >
              Configurações
            </Link>
          </nav>
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="mr-2 md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="pr-0">
            <Link href="/dashboard" className="flex items-center space-x-2">
              <WaterDropIcon className="h-6 w-6 text-blue-600" />
              <span className="font-bold">AquaMonitor</span>
            </Link>
            <nav className="mt-6 flex flex-col space-y-3">
              <Link
                href="/dashboard"
                className={`px-2 py-1 ${pathname === "/dashboard" ? "text-foreground" : "text-foreground/60"}`}
              >
                Dashboard
              </Link>
              <Link
                href="/dashboard/history"
                className={`px-2 py-1 ${pathname === "/dashboard/history" ? "text-foreground" : "text-foreground/60"}`}
              >
                Histórico
              </Link>
              <Link
                href="/dashboard/settings"
                className={`px-2 py-1 ${pathname === "/dashboard/settings" ? "text-foreground" : "text-foreground/60"}`}
              >
                Configurações
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <div className="flex flex-1 items-center justify-end space-x-2">
          <Button variant="outline" size="icon">
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notificações</span>
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                Minha Conta
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/dashboard/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Configurações</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => signOut({ callbackUrl: "/" })}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Sair</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

