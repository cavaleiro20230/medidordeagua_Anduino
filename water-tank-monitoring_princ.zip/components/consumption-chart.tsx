"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function ConsumptionChart() {
  const [activeTab, setActiveTab] = useState("daily")
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Gerar dados simulados com base na aba selecionada
    if (activeTab === "daily") {
      // Dados das últimas 24 horas
      const hourlyData = Array.from({ length: 24 }, (_, i) => {
        const hour = 23 - i
        const now = new Date()
        now.setHours(now.getHours() - hour)
        return {
          time: now.getHours() + ":00",
          consumo: Math.floor(Math.random() * 10) + 3,
        }
      })
      setData(hourlyData)
    } else if (activeTab === "weekly") {
      // Dados dos últimos 7 dias
      const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]
      const dailyData = Array.from({ length: 7 }, (_, i) => {
        const dayIndex = (new Date().getDay() - i + 7) % 7
        return {
          time: days[dayIndex],
          consumo: Math.floor(Math.random() * 50) + 80,
        }
      }).reverse()
      setData(dailyData)
    } else {
      // Dados dos últimos 30 dias
      const monthlyData = Array.from({ length: 30 }, (_, i) => {
        const day = 29 - i
        const date = new Date()
        date.setDate(date.getDate() - day)
        return {
          time: `${date.getDate()}/${date.getMonth() + 1}`,
          consumo: Math.floor(Math.random() * 60) + 90,
        }
      })
      setData(monthlyData)
    }
  }, [activeTab])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Consumo de Água</CardTitle>
        <CardDescription>Visualize o consumo ao longo do tempo</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="daily" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="daily">Diário</TabsTrigger>
            <TabsTrigger value="weekly">Semanal</TabsTrigger>
            <TabsTrigger value="monthly">Mensal</TabsTrigger>
          </TabsList>
          <TabsContent value="daily" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="L" />
                <Tooltip formatter={(value) => [`${value} L`, "Consumo"]} />
                <Line type="monotone" dataKey="consumo" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          <TabsContent value="weekly" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="L" />
                <Tooltip formatter={(value) => [`${value} L`, "Consumo"]} />
                <Line type="monotone" dataKey="consumo" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          <TabsContent value="monthly" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="L" />
                <Tooltip formatter={(value) => [`${value} L`, "Consumo"]} />
                <Line type="monotone" dataKey="consumo" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

