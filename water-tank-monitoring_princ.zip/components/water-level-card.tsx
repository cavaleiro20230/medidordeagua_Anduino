"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function WaterLevelCard() {
  const [waterLevel, setWaterLevel] = useState(75)
  const [lastUpdated, setLastUpdated] = useState("")

  useEffect(() => {
    // Simulação de dados - em um ambiente real, isso viria da API
    const fetchData = () => {
      // Simular variação de nível
      const newLevel = Math.max(0, Math.min(100, waterLevel + (Math.random() * 6 - 3)))
      setWaterLevel(Math.round(newLevel))
      setLastUpdated(new Date().toLocaleTimeString())
    }

    fetchData()
    const interval = setInterval(fetchData, 30000) // Atualiza a cada 30 segundos

    return () => clearInterval(interval)
  }, [waterLevel])

  // Determinar cor baseada no nível
  const getColorClass = () => {
    if (waterLevel < 20) return "text-red-500"
    if (waterLevel < 40) return "text-orange-500"
    return "text-green-500"
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Nível da Caixa d'Água</CardTitle>
        <CardDescription>Atualizado: {lastUpdated}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <span className={`text-2xl font-bold ${getColorClass()}`}>{waterLevel}%</span>
            <span className="text-sm text-muted-foreground">Capacidade total: 1000L</span>
          </div>
          <Progress value={waterLevel} className="h-4" />
          <div className="grid grid-cols-3 text-xs text-muted-foreground">
            <div className="text-red-500">Baixo</div>
            <div className="text-center text-orange-500">Médio</div>
            <div className="text-right text-green-500">Cheio</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

