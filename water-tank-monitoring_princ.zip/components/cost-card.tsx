"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function CostCard() {
  const [cost, setCost] = useState(12.5)
  const [projectedCost, setProjectedCost] = useState(45.8)
  const [lastUpdated, setLastUpdated] = useState("")

  useEffect(() => {
    // Simulação de dados - em um ambiente real, isso viria da API
    const fetchData = () => {
      // Simular variação de custo
      const newCost = Math.max(0, cost + (Math.random() * 0.5 - 0.2))
      setCost(Number.parseFloat(newCost.toFixed(2)))

      // Projeção para o mês
      const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate()
      const dayOfMonth = new Date().getDate()
      const projected = (newCost / dayOfMonth) * daysInMonth
      setProjectedCost(Number.parseFloat(projected.toFixed(2)))

      setLastUpdated(new Date().toLocaleTimeString())
    }

    fetchData()
    const interval = setInterval(fetchData, 3600000) // Atualiza a cada hora

    return () => clearInterval(interval)
  }, [cost])

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Custo Atual</CardTitle>
        <CardDescription>Atualizado: {lastUpdated}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold">R$ {cost.toFixed(2)}</span>
            <span className="text-sm text-muted-foreground">Este mês</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>Projeção mensal:</span>
            <span className="font-medium">R$ {projectedCost.toFixed(2)}</span>
          </div>
          <div className="text-xs text-muted-foreground">Baseado na tarifa de R$ 3,50 por m³</div>
        </div>
      </CardContent>
    </Card>
  )
}

