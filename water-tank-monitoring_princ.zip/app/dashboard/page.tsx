import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import DashboardHeader from "@/components/dashboard-header"
import WaterLevelCard from "@/components/water-level-card"
import ConsumptionCard from "@/components/consumption-card"
import CostCard from "@/components/cost-card"
import ConsumptionChart from "@/components/consumption-chart"
import CostChart from "@/components/cost-chart"
import AlertsCard from "@/components/alerts-card"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <WaterLevelCard />
          <ConsumptionCard />
          <CostCard />
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <ConsumptionChart />
          <CostChart />
        </div>
        <div className="grid gap-4 md:grid-cols-1">
          <AlertsCard />
        </div>
      </main>
    </div>
  )
}

