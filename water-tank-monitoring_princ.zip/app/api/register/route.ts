import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, password } = body

    // Validação básica
    if (!name || !email || !password) {
      return NextResponse.json({ message: "Dados incompletos. Preencha todos os campos." }, { status: 400 })
    }

    // Em um ambiente real, você salvaria os dados no banco de dados
    // Este é apenas um exemplo para demonstração

    // Simular um atraso de rede
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return NextResponse.json({ message: "Usuário registrado com sucesso" }, { status: 201 })
  } catch (error) {
    console.error("Erro ao registrar usuário:", error)
    return NextResponse.json({ message: "Erro ao processar a solicitação" }, { status: 500 })
  }
}

