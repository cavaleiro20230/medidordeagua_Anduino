import { NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"

export async function middleware(req) {
  const token = await getToken({ req })
  const isLoggedIn = !!token
  const { pathname } = req.nextUrl

  const isAuthRoute = pathname.startsWith("/login") || pathname.startsWith("/register")

  const isDashboardRoute = pathname.startsWith("/dashboard")

  // Redireciona usuários não autenticados para login
  if (isDashboardRoute && !isLoggedIn) {
    const url = new URL("/login", req.url)
    url.searchParams.set("callbackUrl", encodeURI(pathname))
    return NextResponse.redirect(url)
  }

  // Redireciona usuários autenticados para dashboard se tentarem acessar login/registro
  if (isAuthRoute && isLoggedIn) {
    return NextResponse.redirect(new URL("/dashboard", req.url))
  }

  return NextResponse.next()
}

// Configuração para que o middleware seja executado em rotas específicas
export const config = {
  matcher: ["/dashboard/:path*", "/login", "/register"],
}

