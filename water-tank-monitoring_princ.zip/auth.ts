import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        // Em um ambiente real, você verificaria as credenciais em um banco de dados
        // Este é apenas um exemplo para demonstração
        if (credentials?.email === "usuario@exemplo.com" && credentials?.password === "senha123") {
          return {
            id: "1",
            name: "Usuário Teste",
            email: "usuario@exemplo.com",
          }
        }

        // Para fins de demonstração, aceita qualquer credencial
        if (credentials?.email && credentials?.password) {
          return {
            id: "2",
            name: "Usuário Demo",
            email: credentials.email,
          }
        }

        return null
      },
    }),
  ],
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 dias
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string
      }
      return session
    },
  },
})

